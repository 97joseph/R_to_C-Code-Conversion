# QuantumAnnealing
Quantum Annealing Solver in C++ : based on a previous project in Java

This solver implements a black box optimisation algorithm, called PIMC-QA (Path Integral Monte Carlo Quantum Annealing).
The implementation of problems is separated from the solver itself, which should allow for easy custom use.
