#ifndef ELEMENTARYMUTATION_H
#define ELEMENTARYMUTATION_H

/**
Interface.
*/
class ElementaryMutation
{
    public:
        ElementaryMutation() {}
        virtual ~ElementaryMutation() {}
    protected:
    private:
};

#endif // ELEMENTARYMUTATION_H

